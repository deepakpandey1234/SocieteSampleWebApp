package com.deepak.test;

import java.util.HashMap;

import com.deepak.societe.com.Model.UserData;

/**
 * @author dpandey
 *
 */
public interface ITodoTest {
 
	public void searchById(Long id);
	
	public void getAllUser();
	
	public void getCount();
	
	public void greetingFromServer();
	
}
